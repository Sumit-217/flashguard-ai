import React, { useState } from 'react';
import { useRiskData } from './hooks/useRiskData';
import { Header } from './components/layout/Header';
import { Sidebar, DashboardPage } from './components/layout/Sidebar';
import { AlertBanner } from './components/layout/AlertBanner';
import { StationDetailModal } from './components/common/StationDetailModal';
import { StationRisk } from './types/api';

// Pages
import { OverviewPage } from './pages/OverviewPage';
import { RiskMapPage } from './pages/RiskMapPage';
import { AlertsPage } from './pages/AlertsPage';
import { BroadcastPage } from './pages/BroadcastPage';
import { StationsPage } from './pages/StationsPage';
import { IncidentsPage } from './pages/IncidentsPage';
import { ResponsePage } from './pages/ResponsePage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { SystemStatusPage } from './pages/SystemStatusPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<DashboardPage>('overview');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [selectedStation, setSelectedStation] = useState<StationRisk | null>(null);

  const {
    isDemo,
    setIsDemo: setDemo,
    scenario: demoScenario,
    isBackendOnline,
    isUsingCachedData,
    loading,
    lastSyncTime: lastUpdated,
    summary,
    geoData,
    health,
    incidents,
    alerts,
    setScenario,
    refresh: refreshData,
    acknowledgeAlert,
    acknowledgeIncident,
    resolveIncident,
  } = useRiskData();

  const activeAlertsCount = alerts.filter((a) => a.status === 'ACTIVE').length;
  const criticalZonesCount = summary?.critical_zones || 0;

  // Handler to view a facility or coordinates on map
  const handleViewLocationOnMap = (coordinates: [number, number]) => {
    setCurrentPage('map');
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-mono select-none">
      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={(page) => {
          setCurrentPage(page);
          setSidebarOpen(false);
        }}
        activeAlertsCount={activeAlertsCount}
        criticalCount={criticalZonesCount}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Operational Header */}
        <Header
          isDemo={isDemo}
          demoScenario={demoScenario}
          isBackendOnline={isBackendOnline}
          isUsingCachedData={isUsingCachedData}
          lastUpdated={lastUpdated}
          loading={loading}
          activeAlertsCount={activeAlertsCount}
          onToggleDemo={() => setDemo(!isDemo)}
          onSelectScenario={setScenario}
          onRefresh={refreshData}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          onNavigateAlerts={() => setCurrentPage('alerts')}
        />

        {/* Global Warning / Backend Fallback Banner */}
        <AlertBanner
          isBackendOnline={isBackendOnline}
          isUsingCachedData={isUsingCachedData}
          isDemo={isDemo}
          demoScenario={demoScenario}
          criticalZonesCount={criticalZonesCount}
          onSwitchToDemo={() => setDemo(true)}
          onSelectScenario={setScenario}
          onViewCriticalZones={() => setCurrentPage('map')}
        />

        {/* Primary Page Canvas */}
        <main className="flex-1 overflow-y-auto bg-[#050507]">
          {currentPage === 'overview' && (
            <OverviewPage
              summary={summary}
              geoData={geoData}
              health={health}
              incidents={incidents}
              alerts={alerts}
              loading={loading}
              onRefresh={refreshData}
              onNavigate={(page) => setCurrentPage(page)}
              onSelectStation={(stn) => setSelectedStation(stn)}
              isDemo={isDemo}
              onToggleDemo={() => setDemo(!isDemo)}
            />
          )}

          {currentPage === 'map' && (
            <RiskMapPage
              stations={summary?.stations || []}
              geoData={geoData}
              onSelectStation={(stn) => setSelectedStation(stn)}
              onRefresh={refreshData}
              loading={loading}
            />
          )}

          {currentPage === 'alerts' && (
            <AlertsPage
              alerts={alerts}
              onAcknowledge={acknowledgeAlert}
              onCreateAlert={() => setCurrentPage('broadcast')}
              onRefresh={refreshData}
              loading={loading}
            />
          )}

          {currentPage === 'broadcast' && (
            <BroadcastPage defaultDistrict={summary?.highest_risk_district} />
          )}

          {currentPage === 'stations' && (
            <StationsPage
              stations={summary?.stations || []}
              onSelectStation={(stn) => setSelectedStation(stn)}
              onRefresh={refreshData}
              loading={loading}
            />
          )}

          {currentPage === 'incidents' && (
            <IncidentsPage
              incidents={incidents}
              onAcknowledge={acknowledgeIncident}
              onResolve={resolveIncident}
              onRefresh={refreshData}
              loading={loading}
              isDemo={isDemo}
            />
          )}

          {currentPage === 'response' && (
            <ResponsePage onViewOnMap={handleViewLocationOnMap} />
          )}

          {currentPage === 'analytics' && (
            <AnalyticsPage
              summary={summary}
              stations={summary?.stations || []}
            />
          )}

          {currentPage === 'system' && (
            <SystemStatusPage
              health={health}
              isBackendOnline={isBackendOnline}
              onRefresh={refreshData}
              loading={loading}
            />
          )}
        </main>
      </div>

      {/* Station Detail Modal */}
      <StationDetailModal
        station={selectedStation}
        onClose={() => setSelectedStation(null)}
      />
    </div>
  );
}
