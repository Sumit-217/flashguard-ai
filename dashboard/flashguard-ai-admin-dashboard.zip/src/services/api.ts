import {
  BroadcastPayload,
  BroadcastResponse,
  DemoScenario,
  DistrictRisk,
  GeoJSONData,
  Incident,
  StateRiskSummary,
  StationRisk,
  SystemHealth,
} from '../types/api';
import { generateScenarioData, SYSTEM_HEALTH_FALLBACK } from '../data/demoData';

// VITE_API_BASE_URL is the primary backend URL specified by the user
const RAW_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined) || '';
export const API_BASE_URL = RAW_BASE_URL.trim().replace(/\/$/, '');

interface FetchResult<T> {
  data: T | null;
  fromBackend: boolean;
  error?: string;
}

// Low-level safe fetch helper with timeout
async function safeFetch<T>(
  path: string,
  options?: RequestInit,
  timeoutMs = 6000
): Promise<{ ok: boolean; status: number; data: T | null; error?: string }> {
  // If no base URL is defined and we are running in browser without a local backend proxy,
  // we attempt relative path first or handle network errors gracefully.
  const url = API_BASE_URL ? `${API_BASE_URL}${path}` : path;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      ...options,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      let errText = `HTTP ${res.status}`;
      try {
        const body = await res.json();
        if (body.detail) errText = String(body.detail);
      } catch {
        // Ignore JSON parse error on non-json error responses
      }
      return { ok: false, status: res.status, data: null, error: errText };
    }

    const data = (await res.json()) as T;
    return { ok: true, status: res.status, data };
  } catch (err: any) {
    clearTimeout(timeoutId);
    return {
      ok: false,
      status: 0,
      data: null,
      error: err.name === 'AbortError' ? 'Connection timed out' : (err.message || 'Network connection failed'),
    };
  }
}

/**
 * Health Check API
 * GET /api/v1/health
 */
export async function getSystemHealth(): Promise<FetchResult<SystemHealth>> {
  const res = await safeFetch<any>('/api/v1/health');
  if (res.ok && res.data) {
    // Standardize backend health schema
    const health: SystemHealth = {
      status: res.data.status === 'OK' || res.data.status === 'CONNECTED' ? 'CONNECTED' : 'DEGRADED',
      backend_version: res.data.version || 'v1.0.0-live',
      uptime: res.data.uptime || 'Active',
      api_endpoint: `${API_BASE_URL || ''}/api/v1`,
      data_freshness_seconds: typeof res.data.data_age === 'number' ? res.data.data_age : 8,
      last_successful_sync: new Date().toISOString(),
      data_sources: res.data.data_sources || SYSTEM_HEALTH_FALLBACK.data_sources,
      notification_service: res.data.notification_service || SYSTEM_HEALTH_FALLBACK.notification_service,
    };
    return { data: health, fromBackend: true };
  }

  return {
    data: {
      ...SYSTEM_HEALTH_FALLBACK,
      status: 'OFFLINE',
    },
    fromBackend: false,
    error: res.error || 'Backend unavailable',
  };
}

/**
 * State Risk Summary API
 * GET /api/v1/risk/uttarakhand or GET /api/v1/demo/risk/uttarakhand
 */
export async function getUttarakhandRisk(
  isDemo = false,
  scenario: DemoScenario = 'NORMAL'
): Promise<FetchResult<StateRiskSummary>> {
  if (isDemo) {
    // First try backend demo endpoint if available
    const res = await safeFetch<any>(`/api/v1/demo/risk/uttarakhand?scenario=${scenario.toLowerCase()}`);
    if (res.ok && res.data && res.data.stations) {
      return { data: res.data as StateRiskSummary, fromBackend: true };
    }
    // Return controlled scenario data locally
    const scenarioData = generateScenarioData(scenario);
    return { data: scenarioData.summary, fromBackend: false };
  }

  // LIVE mode
  const res = await safeFetch<any>('/api/v1/risk/uttarakhand');
  if (res.ok && res.data) {
    return { data: res.data as StateRiskSummary, fromBackend: true };
  }

  return {
    data: null,
    fromBackend: false,
    error: res.error || 'Backend risk service unavailable',
  };
}

/**
 * District-level Risk API
 * GET /api/v1/risk/district/{district}
 */
export async function getDistrictRisk(
  district: string,
  isDemo = false,
  scenario: DemoScenario = 'NORMAL'
): Promise<FetchResult<DistrictRisk>> {
  if (isDemo) {
    const scenarioData = generateScenarioData(scenario);
    const dist = scenarioData.districts.find(
      (d) => d.district.toLowerCase() === district.toLowerCase()
    );
    return {
      data: dist || {
        district,
        risk_level: 'LOW',
        risk_score: 15,
        critical_zones_count: 0,
        active_stations_count: 0,
        avg_rainfall_24h: 12,
      },
      fromBackend: false,
    };
  }

  const res = await safeFetch<DistrictRisk>(`/api/v1/risk/district/${encodeURIComponent(district)}`);
  if (res.ok && res.data) {
    return { data: res.data, fromBackend: true };
  }
  return { data: null, fromBackend: false, error: res.error };
}

/**
 * Station-level Risk API
 * GET /api/v1/risk/station/{station}
 */
export async function getStationRisk(
  stationId: string,
  isDemo = false,
  scenario: DemoScenario = 'NORMAL'
): Promise<FetchResult<StationRisk>> {
  if (isDemo) {
    const scenarioData = generateScenarioData(scenario);
    const stn = scenarioData.stations.find(
      (s) => s.id.toLowerCase() === stationId.toLowerCase() || s.name.toLowerCase().includes(stationId.toLowerCase())
    );
    return {
      data: stn || null,
      fromBackend: false,
    };
  }

  const res = await safeFetch<StationRisk>(`/api/v1/risk/station/${encodeURIComponent(stationId)}`);
  if (res.ok && res.data) {
    return { data: res.data, fromBackend: true };
  }
  return { data: null, fromBackend: false, error: res.error };
}

/**
 * GeoJSON Endpoint
 * GET /api/v1/risk/uttarakhand/geojson
 * IMPORTANT: GeoJSON uses [longitude, latitude].
 */
export async function getUttarakhandGeoJSON(
  isDemo = false,
  scenario: DemoScenario = 'NORMAL'
): Promise<FetchResult<GeoJSONData>> {
  if (!isDemo) {
    const res = await safeFetch<GeoJSONData>('/api/v1/risk/uttarakhand/geojson');
    if (res.ok && res.data && res.data.type === 'FeatureCollection') {
      return { data: res.data, fromBackend: true };
    }
  }

  // Generate GeoJSON from scenario stations
  const scenarioData = generateScenarioData(scenario);
  const geojson: GeoJSONData = {
    type: 'FeatureCollection',
    features: scenarioData.stations.map((s) => ({
      type: 'Feature',
      properties: {
        id: s.id,
        name: s.name,
        district: s.district,
        risk_level: s.risk_level,
        risk_score: s.risk_score,
        rainfall_24h: s.rainfall_24h,
        water_level: s.water_level,
        danger_level: s.danger_level,
        status: s.status,
        last_updated: s.last_updated,
        data_source: s.data_source,
      },
      geometry: {
        type: 'Point',
        // Note standard GeoJSON coordinate order: [longitude, latitude]
        coordinates: [s.coordinates[1], s.coordinates[0]],
      },
    })),
  };

  return {
    data: geojson,
    fromBackend: false,
  };
}

/**
 * Rainfall API
 * GET /api/v1/rainfall/uttarakhand
 */
export async function getUttarakhandRainfall(): Promise<FetchResult<any>> {
  const res = await safeFetch<any>('/api/v1/rainfall/uttarakhand');
  if (res.ok && res.data) {
    return { data: res.data, fromBackend: true };
  }
  return { data: null, fromBackend: false, error: res.error || 'Rainfall data unavailable' };
}

/**
 * Emergency Broadcast API
 * POST /api/v1/alerts
 * As specified in user requirements:
 * "If the backend endpoint does not exist yet, create the UI but clearly show:
 *  Backend alert service not configured
 *  Do not pretend the alert was delivered."
 */
export async function sendEmergencyBroadcast(
  payload: BroadcastPayload
): Promise<BroadcastResponse> {
  const res = await safeFetch<any>('/api/v1/alerts', {
    method: 'POST',
    body: JSON.stringify(payload),
  });

  if (res.ok && res.data) {
    return {
      success: true,
      alert_id: res.data.id || res.data.alert_id || `ALT-${Date.now()}`,
      broadcast_time: new Date().toISOString(),
      message: res.data.message || 'Alert broadcast received by backend.',
      is_simulated: false,
    };
  }

  // Backend returned 404, 501, 500 or network offline
  return {
    success: false,
    message: 'Backend alert service not configured',
    is_simulated: false,
  };
}
