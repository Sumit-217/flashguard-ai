import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  AlertTriangle,
  ExternalLink,
  Layers,
  MapPin,
  Maximize2,
  Minimize2,
  RefreshCw,
  Search,
  Sliders,
} from 'lucide-react';
import { GeoJSONData, RiskLevel, StationRisk } from '../../types/api';
import { UTTARAKHAND_DISTRICTS } from '../../data/demoData';

interface RiskMapProps {
  stations: StationRisk[];
  geoData: GeoJSONData | null;
  onSelectStation: (station: StationRisk) => void;
  isEmbedded?: boolean;
  onExpandToFullMap?: () => void;
  initialCenter?: [number, number];
}

const RISK_COLORS: Record<RiskLevel, { hex: string; bg: string; text: string }> = {
  LOW: { hex: '#22c55e', bg: 'bg-emerald-500', text: 'text-emerald-400' },
  MODERATE: { hex: '#eab308', bg: 'bg-amber-500', text: 'text-amber-400' },
  HIGH: { hex: '#f97316', bg: 'bg-orange-500', text: 'text-orange-400' },
  CRITICAL: { hex: '#ef4444', bg: 'bg-red-500', text: 'text-red-400' },
};

export const RiskMap: React.FC<RiskMapProps> = ({
  stations,
  geoData,
  onSelectStation,
  isEmbedded = false,
  onExpandToFullMap,
  initialCenter,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  // Filters
  const [riskFilter, setRiskFilter] = useState<'ALL' | RiskLevel>('ALL');
  const [districtFilter, setDistrictFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Filtered stations list
  const filteredStations = stations.filter((stn) => {
    if (riskFilter !== 'ALL' && stn.risk_level !== riskFilter) return false;
    if (districtFilter !== 'ALL' && stn.district !== districtFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = stn.name.toLowerCase().includes(q);
      const matchId = stn.id.toLowerCase().includes(q);
      const matchDist = stn.district.toLowerCase().includes(q);
      if (!matchName && !matchId && !matchDist) return false;
    }
    return true;
  });

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const initialCoords = initialCenter || [30.25, 79.15];
      const map = L.map(mapContainerRef.current, {
        center: initialCoords,
        zoom: isEmbedded ? 7 : 8,
        minZoom: 6,
        maxZoom: 15,
        zoomControl: !isEmbedded,
        attributionControl: false,
      });

      // Dark CartoDB Matter tile layer
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      // Attribution
      L.control
        .attribution({ position: 'bottomleft', prefix: false })
        .addAttribution('&copy; OpenStreetMap, &copy; CARTO | FlashGuard AI')
        .addTo(map);

      const markersGroup = L.layerGroup().addTo(map);
      markersLayerRef.current = markersGroup;
      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markersLayerRef.current = null;
      }
    };
  }, [isEmbedded]);

  // Update Markers whenever filtered stations or geoData change
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersGroup = markersLayerRef.current;
    if (!map || !markersGroup) return;

    markersGroup.clearLayers();

    filteredStations.forEach((station) => {
      const color = RISK_COLORS[station.risk_level] || RISK_COLORS.LOW;
      const isCritical = station.risk_level === 'CRITICAL';
      const isHigh = station.risk_level === 'HIGH';

      // Custom HTML Marker using DivIcon
      const htmlIcon = `
        <div class="relative flex items-center justify-center cursor-pointer group" style="width: 28px; height: 28px;">
          ${
            isCritical
              ? `<div class="radar-ping absolute w-7 h-7 rounded-full bg-red-500/40"></div>`
              : isHigh
              ? `<div class="animate-pulse absolute w-6 h-6 rounded-full bg-orange-500/30"></div>`
              : ''
          }
          <div style="background-color: ${color.hex}; border: 2px solid #0f172a; box-shadow: 0 0 10px ${color.hex}80;" 
               class="w-3.5 h-3.5 rounded-full z-10 transition-transform group-hover:scale-125">
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        html: htmlIcon,
        className: 'custom-station-pin',
        iconSize: [28, 28],
        iconAnchor: [14, 14],
        popupAnchor: [0, -14],
      });

      const marker = L.marker([station.coordinates[0], station.coordinates[1]], {
        icon: customIcon,
      });

      // Dark styled popup
      const popupContent = document.createElement('div');
      popupContent.className = 'text-xs font-mono select-text';
      popupContent.innerHTML = `
        <div class="space-y-2 p-1">
          <div class="flex items-center justify-between border-b border-slate-700 pb-1.5 gap-2">
            <span class="font-bold text-slate-100 text-sm truncate">${station.name}</span>
            <span class="px-1.5 py-0.5 rounded text-[10px] uppercase font-bold" 
                  style="background-color: ${color.hex}25; color: ${color.hex}; border: 1px solid ${color.hex}80;">
              ${station.risk_level} (${station.risk_score})
            </span>
          </div>

          <div class="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] text-slate-300">
            <div><span class="text-slate-500 text-[10px] block">DISTRICT</span>${station.district}</div>
            <div><span class="text-slate-500 text-[10px] block">STATUS</span><span class="${station.status === 'ONLINE' ? 'text-emerald-400' : 'text-red-400'}">● ${station.status}</span></div>
            <div><span class="text-slate-500 text-[10px] block">24H RAINFALL</span><strong class="text-blue-400 font-bold">${station.rainfall_24h} mm</strong></div>
            <div><span class="text-slate-500 text-[10px] block">1H RAINFALL</span><strong class="text-blue-300">${station.rainfall_1h} mm</strong></div>
            ${
              station.water_level !== undefined && station.danger_level !== undefined
                ? `<div class="col-span-2 text-[10px]"><span class="text-slate-500">RIVER STAGE:</span> <strong class="${station.water_level >= station.danger_level ? 'text-red-400' : 'text-slate-200'}">${station.water_level}m</strong> / Danger: ${station.danger_level}m</div>`
                : ''
            }
            <div class="col-span-2 text-[10px] text-slate-500 truncate">
              SRC: ${station.data_source}
            </div>
          </div>

          <div class="pt-2 border-t border-slate-700/80 flex justify-end">
            <button id="open-details-${station.id}" 
                    class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded border border-slate-600 text-xs font-mono transition-colors flex items-center gap-1">
              <span>Open Details</span>
              <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
            </button>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent, { maxWidth: 320 });

      marker.on('popupopen', () => {
        const btn = document.getElementById(`open-details-${station.id}`);
        if (btn) {
          btn.onclick = () => {
            onSelectStation(station);
            marker.closePopup();
          };
        }
      });

      marker.addTo(markersGroup);
    });
  }, [filteredStations, onSelectStation]);

  // Center on coordinates if requested
  useEffect(() => {
    if (initialCenter && mapInstanceRef.current) {
      mapInstanceRef.current.setView(initialCenter, 10, { animate: true });
    }
  }, [initialCenter]);

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-950 rounded-lg overflow-hidden border border-slate-800">
      {/* Map Control Bar (for full map mode) */}
      {!isEmbedded && (
        <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono z-10">
          <div className="flex flex-wrap items-center gap-2">
            {/* Risk filter */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded border border-slate-800">
              <span className="text-slate-500 px-1 text-[11px] uppercase">Risk:</span>
              {(['ALL', 'CRITICAL', 'HIGH', 'MODERATE', 'LOW'] as const).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setRiskFilter(lvl)}
                  className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
                    riskFilter === lvl
                      ? lvl === 'CRITICAL'
                        ? 'bg-red-600 text-white font-bold'
                        : lvl === 'HIGH'
                        ? 'bg-orange-600 text-white font-bold'
                        : lvl === 'MODERATE'
                        ? 'bg-amber-600 text-white font-bold'
                        : lvl === 'LOW'
                        ? 'bg-emerald-600 text-white font-bold'
                        : 'bg-slate-700 text-white font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>

            {/* District filter */}
            <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
              <span className="text-slate-500 text-[11px] uppercase">District:</span>
              <select
                value={districtFilter}
                onChange={(e) => setDistrictFilter(e.target.value)}
                className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-slate-900 text-slate-200">
                  All Districts (13)
                </option>
                {UTTARAKHAND_DISTRICTS.map((d) => (
                  <option key={d} value={d} className="bg-slate-900 text-slate-200">
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Search bar */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search station or ID..."
                className="pl-8 pr-3 py-1 bg-slate-950 border border-slate-800 rounded text-slate-200 placeholder-slate-500 text-xs w-48 sm:w-56 focus:outline-none focus:border-slate-600"
              />
            </div>
            <div className="text-[11px] text-slate-400 px-2 py-1 bg-slate-950 rounded border border-slate-800">
              Showing <strong className="text-white">{filteredStations.length}</strong> / {stations.length}
            </div>
          </div>
        </div>
      )}

      {/* Embedded Map Header */}
      {isEmbedded && (
        <div className="p-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-red-500" />
            <span className="font-bold text-slate-200">LIVE RISK MAP (UTTARAKHAND)</span>
          </div>
          {onExpandToFullMap && (
            <button
              type="button"
              onClick={onExpandToFullMap}
              className="flex items-center gap-1 text-slate-400 hover:text-slate-100 transition-colors text-[11px]"
            >
              <span>View Full Map</span>
              <Maximize2 className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* Map Canvas */}
      <div ref={mapContainerRef} className="flex-1 w-full min-h-[300px]" />

      {/* Floating Legend */}
      <div className="absolute bottom-3 left-3 bg-slate-950/90 backdrop-blur-xs border border-slate-800 p-2 rounded shadow-lg text-[10px] font-mono text-slate-300 z-10 pointer-events-none">
        <div className="font-bold text-slate-400 mb-1 uppercase tracking-wider text-[9px]">
          Disaster Risk Thresholds
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            <span>LOW</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
            <span>MODERATE</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500 inline-block" />
            <span>HIGH</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" />
            <span>CRITICAL</span>
          </div>
        </div>
      </div>
    </div>
  );
};
